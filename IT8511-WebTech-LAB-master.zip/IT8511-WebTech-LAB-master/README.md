# IT8511 - Web Technology Lab

## Topics
1. [Design your own webpage.](/01%20-%20DESIGN%20YOUR%20OWN%20WEBPAGE)
2. [Web page creation using Hotspot.](/02%20-%20WEB%20PAGE%20CREATION%20USING%20HOTSPOT)
3. To be continued...

## A note about HTML
Verse 1:<br>
Listen up y'all, I gotta confess <br>
HTML's got me feeling quite stressed<br>
Used to think it was the way to go<br>
But now I'm like, "No, no, no!"<br>

Chorus:<br>
HTML's got me feeling so sad<br>
Every time I code, I feel bad<br>
Tables and divs, oh what a mess<br>
HTML, you're just not the best<br>

Verse 2:<br>
Trying to style it, what a pain<br>
Takes forever, driving me insane<br>
Trying to make it look nice<br>
But it just doesn't cut the ice<br>

Chorus:<br>
HTML's got me feeling so sad<br>
Every time I code, I feel bad<br>
Tables and divs, oh what a mess<br>
HTML, you're just not the best<br>

Bridge:<br>
I want a language that's clean and neat<br>
A language that can't be beat<br>
Where styling's easy and it flows<br>
That's why I say, "HTML, time to go!"<br>

Chorus:<br>
HTML's got me feeling so sad<br>
Every time I code, I feel bad<br>
Tables and divs, oh what a mess<br>
HTML, you're just not the best<br>

Outro:<br>
So if you're tired of the HTML game<br>
Join me in finding a new aim<br>
A language that makes coding a breeze<br>
And HTML, we'll say our goodbyes with ease.<br>