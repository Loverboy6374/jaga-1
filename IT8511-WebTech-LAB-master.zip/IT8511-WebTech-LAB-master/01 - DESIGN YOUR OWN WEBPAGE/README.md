# 01 - DESIGN YOUR OWN WEBPAGE
## Output
### index.html
<p style="align-content: stretch">
<img src="out/index.jpg" alt="">
</p>

### abc.html
<p style="align-content: stretch">
<img src="out/abc.jpg" alt="">
</p>

### xyz.html
<p style="align-content: stretch">
<img src="out/xyz.jpg" alt="">
</p>