#  02 - WEB PAGE CREATION USING HOTSPOT
## Output
### front.html
<p style="align-content: stretch">
<img src="out/front.png" alt="">
</p>